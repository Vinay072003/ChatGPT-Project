// Provide all the crdentials here



// Your WiFi Credentials 
const char *ssid = "Sinhgad-Open-WiFi";       // WiFi SSID Name
const char *password = "";// WiFi Password ( Keep it blank if your WiFi router is open )


// Parameters of Google Speech to Text API
const String ApiKey = "AIzaSyA87UOP95RJq14T40czg-5dbt_BpjyZ0mo";// Google Speech to Text API key AIzaSyA87UOP95RJq14T40czg-5dbt_BpjyZ0mo   AIzaSyCsydx6-eGt5PTz6SpRlZ4Og-lpcpwzHO0
String SpeechtoText_Language = "en-IN"; // Language 

// Parameters of OpenAI API 
const char* chatgpt_token = "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"; // OpenAI API Key
String OpenAI_Model = "gpt-3.5-turbo-0125"; // Model
String OpenAI_Temperature = "0.20"; // temperature
String OpenAI_Max_Tokens = "30"; //Max Tokens 
