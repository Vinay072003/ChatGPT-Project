ESP32 Boards Package Link - https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
